const $ = (id) => document.getElementById(id);
const cfg = window.GRID_CONFIG || {};

const state = {
  idToken: null,
  groups: [],
  email: null,
  activeHeatId: null,
  tracks: [],
};

function apiUrl(path) {
  return `${(cfg.apiBase || '').replace(/\/$/, '')}${path}`;
}

function authHeaders() {
  return {
    Accept: 'application/json',
    Authorization: `Bearer ${state.idToken}`,
  };
}

function isDirector() {
  return state.groups.includes('director');
}

function cognitoRegion() {
  if (cfg.region) return cfg.region;
  const pool = cfg.userPoolId || '';
  const idx = pool.indexOf('_');
  if (idx > 0) return pool.slice(0, idx);
  throw new Error('Set region or userPoolId in config.js');
}

async function cognitoSignIn(username, password) {
  const region = cognitoRegion();
  const res = await fetch(`https://cognito-idp.${region}.amazonaws.com/`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-amz-json-1.1',
      'X-Amz-Target': 'AWSCognitoIdentityProviderService.InitiateAuth',
    },
    body: JSON.stringify({
      AuthFlow: 'USER_PASSWORD_AUTH',
      ClientId: cfg.clientId,
      AuthParameters: { USERNAME: username, PASSWORD: password },
    }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || data.__type || 'sign-in failed');
  return data.AuthenticationResult;
}

function parseGroups(idToken) {
  try {
    const payload = JSON.parse(atob(idToken.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
    return payload['cognito:groups'] || [];
  } catch {
    return [];
  }
}

async function apiGet(path) {
  const res = await fetch(apiUrl(path), { headers: authHeaders() });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(body.error || res.statusText);
  return body;
}

async function apiPost(path, payload) {
  const res = await fetch(apiUrl(path), {
    method: 'POST',
    headers: { ...authHeaders(), 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(body.error || res.statusText);
  return { status: res.status, body };
}

async function loadTracks() {
  const data = await apiGet('/api/tracks');
  state.tracks = data.tracks || [];
  const sel = $('track-select');
  sel.innerHTML = state.tracks.map((t) => `<option value="${t.track_id}">${t.name}</option>`).join('');
}

async function loadRulesVersion() {
  const data = await apiGet('/api/config/rules/version');
  $('rules-version').textContent = data.version || '—';
}

async function refreshLeaderboard() {
  const heatId = $('heat-id').value.trim() || state.activeHeatId;
  if (!heatId) return;
  const data = await apiGet(`/api/heats/${heatId}/leaderboard`);
  const tbody = $('leaderboard').querySelector('tbody');
  tbody.innerHTML = (data.standings || []).map((r) => `
    <tr>
      <td>${r.position}</td>
      <td>${r.display_name}</td>
      <td>${r.team}</td>
      <td>${(r.best_lap_ms / 1000).toFixed(3)}s</td>
      <td>${r.gap_ms ? (r.gap_ms / 1000).toFixed(3) + 's' : '—'}</td>
    </tr>`).join('');
}

function showApp() {
  $('auth-panel').classList.add('hidden');
  $('app-panel').classList.remove('hidden');
  $('user-label').textContent = `${state.email} (${state.groups.join(', ')})`;
  $('director-panel').classList.toggle('hidden', !isDirector());
}

$('signin-btn').addEventListener('click', async () => {
  $('auth-status').textContent = 'Signing in…';
  try {
    const tokens = await cognitoSignIn($('email').value.trim(), $('password').value);
    state.idToken = tokens.IdToken;
    state.groups = parseGroups(tokens.IdToken);
    state.email = $('email').value.trim();
    showApp();
    await loadTracks();
    await loadRulesVersion();
    $('auth-status').textContent = '';
  } catch (e) {
    $('auth-status').textContent = e.message;
  }
});

$('signout-btn').addEventListener('click', () => {
  state.idToken = null;
  $('app-panel').classList.add('hidden');
  $('auth-panel').classList.remove('hidden');
});

$('create-heat-btn').addEventListener('click', async () => {
  $('heat-status').textContent = 'Creating…';
  try {
    const { body } = await apiPost('/api/heats', {
      track_id: $('track-select').value,
      label: $('heat-label').value,
      duration_seconds: Number($('heat-duration').value),
    });
    state.activeHeatId = body.heat_id;
    $('heat-id').value = body.heat_id;
    $('start-heat-btn').disabled = false;
    $('heat-status').textContent = `Created ${body.heat_id}`;
  } catch (e) {
    $('heat-status').textContent = e.message;
  }
});

$('start-heat-btn').addEventListener('click', async () => {
  if (!state.activeHeatId) return;
  $('heat-status').textContent = 'Starting…';
  try {
    await apiPost(`/api/heats/${state.activeHeatId}/start`, {});
    $('heat-status').textContent = `Started ${state.activeHeatId}`;
  } catch (e) {
    $('heat-status').textContent = e.message;
  }
});

$('refresh-btn').addEventListener('click', () => refreshLeaderboard().catch((e) => {
  $('heat-status').textContent = e.message;
}));
