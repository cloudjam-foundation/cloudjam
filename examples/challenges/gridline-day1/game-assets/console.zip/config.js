// Wire Cognito + CloudFront, then set userPoolId and clientId before publishing.
// region is optional when userPoolId includes the region prefix (e.g. REGION_poolId).
window.GRID_CONFIG = {
  region: '',
  userPoolId: '',
  clientId: '',
  apiBase: '',
};
