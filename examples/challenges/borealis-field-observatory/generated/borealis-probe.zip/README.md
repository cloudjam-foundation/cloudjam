# Borealis probe

Run `./borealis-probe -endpoint URL` to submit an attention observation and wait for it through Athena.
