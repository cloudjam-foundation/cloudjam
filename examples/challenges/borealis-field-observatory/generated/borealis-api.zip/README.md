# Borealis field API

Build with `docker build -t borealis-api .`. The image listens on port 8080 and provides `GET /health`, `POST /observations`, and `GET /observations/{observation_id}`.

Required environment variables: `IOT_ENDPOINT`, `IOT_TOPIC`, `APPCONFIG_APPLICATION`, `APPCONFIG_ENVIRONMENT`, `APPCONFIG_PROFILE`, `ATHENA_DATABASE`, `ATHENA_TABLE`, and `ATHENA_WORKGROUP`.
