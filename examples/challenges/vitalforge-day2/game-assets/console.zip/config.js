// Fill after Cognito + CloudFront are wired. apiBase '' = same origin.
window.VITALFORGE = {
  region: 'us-east-1',
  userPoolId: 'REPLACE_ME',
  clientId: 'REPLACE_ME',
  apiBase: '',
};
