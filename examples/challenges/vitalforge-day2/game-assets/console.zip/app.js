/* VitalForge console — Cognito USER_PASSWORD_AUTH + same-origin API */
const $ = (id) => document.getElementById(id);
const cfg = window.VITALFORGE || {};

const state = {
  idToken: null,
  accessToken: null,
  groups: [],
  username: null,
  memberUserId: null,
  selectedMemberId: null,
};

function apiUrl(path) {
  const base = (cfg.apiBase || '').replace(/\/$/, '');
  return `${base}${path}`;
}

function authHeaders() {
  const token = state.idToken || state.accessToken;
  return {
    Accept: 'application/json',
    Authorization: `Bearer ${token}`,
  };
}

function decodeJwtPayload(token) {
  try {
    const part = token.split('.')[1];
    const json = atob(part.replace(/-/g, '+').replace(/_/g, '/'));
    return JSON.parse(json);
  } catch {
    return {};
  }
}

function groupsFromToken(idToken) {
  const payload = decodeJwtPayload(idToken);
  const g = payload['cognito:groups'] || payload.groups || [];
  return Array.isArray(g) ? g : [];
}

function memberUserIdFromToken(idToken, username) {
  const payload = decodeJwtPayload(idToken);
  return payload['cognito:username'] || payload.preferred_username || username;
}

async function cognitoSignIn(username, password) {
  const region = cfg.region || 'us-east-1';
  const url = `https://cognito-idp.${region}.amazonaws.com/`;
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-amz-json-1.1',
      'X-Amz-Target': 'AWSCognitoIdentityProviderService.InitiateAuth',
    },
    body: JSON.stringify({
      AuthFlow: 'USER_PASSWORD_AUTH',
      ClientId: cfg.clientId,
      AuthParameters: {
        USERNAME: username,
        PASSWORD: password,
      },
    }),
  });
  const data = await res.json();
  if (!res.ok || data.__type || !data.AuthenticationResult) {
    const msg = data.message || data.__type || `HTTP ${res.status}`;
    throw new Error(msg);
  }
  return data.AuthenticationResult;
}

function showLoginError(msg) {
  const el = $('login-error');
  el.hidden = !msg;
  el.textContent = msg || '';
  el.className = msg ? 'hint err' : 'hint';
}

async function apiGet(path) {
  const res = await fetch(apiUrl(path), { headers: authHeaders() });
  const text = await res.text();
  let data = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = { raw: text };
  }
  if (res.status === 401) throw new Error('Session expired — sign in again');
  if (!res.ok) throw new Error((data && data.error) || `${res.status} ${res.statusText}`);
  return data;
}

async function apiPost(path, body) {
  const res = await fetch(apiUrl(path), {
    method: 'POST',
    headers: { ...authHeaders(), 'Content-Type': 'application/json' },
    body: JSON.stringify(body ?? {}),
  });
  const text = await res.text();
  let data = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = { raw: text };
  }
  if (res.status === 401) throw new Error('Session expired — sign in again');
  if (!res.ok) throw new Error((data && data.error) || `${res.status} ${res.statusText}`);
  return data;
}

function renderStats(container, dashboard) {
  const a = dashboard.analytics || {};
  container.innerHTML = `
    <div class="stat"><div class="label">Meals today</div><div class="value">${dashboard.meals_today ?? '—'}</div></div>
    <div class="stat"><div class="label">Workouts today</div><div class="value">${dashboard.workouts_today ?? '—'}</div></div>
    <div class="stat"><div class="label">Calorie balance</div><div class="value">${a.calorie_balance ?? '—'}</div></div>
    <div class="stat"><div class="label">Protein %</div><div class="value">${a.protein_progress_pct ?? '—'}%</div></div>
    <div class="stat"><div class="label">Sleep score</div><div class="value">${a.sleep_score ?? '—'}</div></div>
    <div class="stat"><div class="label">Thresholds</div><div class="value" style="font-size:0.85rem">${a.thresholds_version ?? '—'}</div></div>
  `;
}

async function loadHealth() {
  const el = $('health-badge');
  try {
    const res = await fetch('/health');
    const data = await res.json();
    const ok = data.status === 'ok';
    el.textContent = ok ? 'API healthy' : 'API degraded';
    el.className = `badge ${ok ? 'ok' : 'err'}`;
  } catch {
    el.textContent = 'API unreachable';
    el.className = 'badge err';
  }
}

async function loadThresholdVersion() {
  const el = $('threshold-badge');
  if (!state.idToken) {
    el.textContent = 'thresholds —';
    return;
  }
  try {
    const data = await apiGet('/api/config/thresholds/version');
    el.textContent = `thresholds ${data.version || '—'}`;
    el.className = 'badge ok';
  } catch {
    el.textContent = 'thresholds unavailable';
    el.className = 'badge err';
  }
}

async function loadMembers() {
  const grid = $('members-grid');
  grid.innerHTML = '<p class="hint">Loading members…</p>';
  try {
    const data = await apiGet('/api/members');
    const members = data.members || [];
    if (!members.length) {
      grid.innerHTML = '<p class="hint">No members returned.</p>';
      return;
    }
    grid.innerHTML = members
      .map(
        (m) => `
      <article class="card${state.selectedMemberId === m.user_id ? ' active' : ''}" data-member="${m.user_id}">
        <h4>${m.display_name || m.user_id}</h4>
        <p>${m.user_id}</p>
      </article>`,
      )
      .join('');
    grid.querySelectorAll('[data-member]').forEach((card) => {
      card.addEventListener('click', () => selectMember(card.getAttribute('data-member')));
    });
    if (!state.selectedMemberId && members[0]) {
      await selectMember(members[0].user_id);
    }
  } catch (err) {
    grid.innerHTML = `<p class="hint err">${err.message}</p>`;
  }
}

async function selectMember(userId) {
  state.selectedMemberId = userId;
  $('coach-detail').hidden = false;
  $('detail-title').textContent = `Dashboard — ${userId}`;
  $('dashboard-json').textContent = 'Loading…';
  $('export-json').hidden = true;
  document.querySelectorAll('.card').forEach((c) => {
    c.classList.toggle('active', c.getAttribute('data-member') === userId);
  });
  try {
    const dashboard = await apiGet(`/api/members/${encodeURIComponent(userId)}/dashboard`);
    renderStats($('dashboard-cards'), dashboard);
    $('dashboard-json').textContent = JSON.stringify(dashboard, null, 2);
  } catch (err) {
    $('dashboard-cards').innerHTML = '';
    $('dashboard-json').textContent = `Failed: ${err.message}`;
  }
}

async function queueExport() {
  if (!state.selectedMemberId) return;
  try {
    const data = await apiPost(`/api/members/${encodeURIComponent(state.selectedMemberId)}/export`, {});
    $('export-json').hidden = false;
    $('export-json').textContent = JSON.stringify(data, null, 2);
  } catch (err) {
    $('export-json').hidden = false;
    $('export-json').textContent = `Export queue failed: ${err.message}`;
  }
}

async function viewExport(userId, targetId) {
  const el = $(targetId);
  el.textContent = 'Loading export…';
  try {
    const data = await apiGet(`/api/export/${encodeURIComponent(userId)}/latest`);
    el.textContent = JSON.stringify(data, null, 2);
  } catch (err) {
    el.textContent = `Export not available: ${err.message}`;
  }
}

async function loadMemberDashboard() {
  const userId = state.memberUserId;
  $('member-dashboard').textContent = 'Loading…';
  try {
    const dashboard = await apiGet(`/api/members/${encodeURIComponent(userId)}/dashboard`);
    renderStats($('member-stats'), dashboard);
    $('member-dashboard').textContent = JSON.stringify(dashboard, null, 2);
  } catch (err) {
    $('member-stats').innerHTML = '';
    $('member-dashboard').textContent = `Failed: ${err.message}`;
  }
}

function setSignedIn(result, username) {
  state.idToken = result.IdToken;
  state.accessToken = result.AccessToken;
  state.username = username;
  state.groups = groupsFromToken(result.IdToken || result.AccessToken);
  state.memberUserId = memberUserIdFromToken(state.idToken, username);

  $('login-panel').hidden = true;
  $('app-panel').hidden = false;
  $('session-badge').textContent = `${username} · ${state.groups.join(', ') || 'no group'}`;

  const isCoach = state.groups.includes('coach');
  const isMember = state.groups.includes('member') || !isCoach;

  $('coach-view').hidden = !isCoach;
  $('member-view').hidden = !isMember;
  $('role-title').textContent = isCoach ? 'Coach workspace' : 'Member workspace';

  loadThresholdVersion();

  if (isCoach) {
    loadMembers();
  }
  if (isMember) {
    loadMemberDashboard();
    viewExport(state.memberUserId, 'member-export');
  }
}

function signOut() {
  state.idToken = null;
  state.accessToken = null;
  state.groups = [];
  state.username = null;
  state.memberUserId = null;
  state.selectedMemberId = null;
  $('app-panel').hidden = true;
  $('login-panel').hidden = false;
  $('session-badge').textContent = 'signed out';
  showLoginError('');
  $('threshold-badge').textContent = 'thresholds —';
  $('threshold-badge').className = 'badge muted';
}

$('login-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  showLoginError('');
  const username = $('username').value.trim();
  const password = $('password').value;
  try {
    if (!cfg.clientId || String(cfg.clientId).includes('REPLACE')) {
      throw new Error('Set VITALFORGE.clientId in config.js');
    }
    const result = await cognitoSignIn(username, password);
    setSignedIn(result, username);
  } catch (err) {
    showLoginError(err.message || String(err));
  }
});

$('sign-out').addEventListener('click', signOut);
$('refresh-members').addEventListener('click', loadMembers);
$('trigger-export').addEventListener('click', queueExport);
$('view-export').addEventListener('click', () => {
  if (state.selectedMemberId) viewExport(state.selectedMemberId, 'export-json');
  $('export-json').hidden = false;
});
$('member-view-export').addEventListener('click', () => viewExport(state.memberUserId, 'member-export'));

$('meal-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  $('meal-result').textContent = 'Saving…';
  try {
    const data = await apiPost('/api/meals', {
      user_id: state.memberUserId,
      calories: Number($('meal-calories').value),
      protein_g: Number($('meal-protein').value),
      description: $('meal-desc').value,
    });
    $('meal-result').textContent = JSON.stringify(data, null, 2);
    await loadMemberDashboard();
  } catch (err) {
    $('meal-result').textContent = `Failed: ${err.message}`;
  }
});

$('workout-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  $('workout-result').textContent = 'Saving…';
  try {
    const data = await apiPost('/api/workouts', {
      user_id: state.memberUserId,
      activity: $('workout-activity').value,
      duration_min: Number($('workout-duration').value),
      calories_burned: Number($('workout-calories').value),
    });
    $('workout-result').textContent = JSON.stringify(data, null, 2);
    await loadMemberDashboard();
  } catch (err) {
    $('workout-result').textContent = `Failed: ${err.message}`;
  }
});

loadHealth();
