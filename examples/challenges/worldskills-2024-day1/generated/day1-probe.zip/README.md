# day1-probe

Run `./day1-probe -ingest-url URL` with competition-account AWS credentials to send a unique code and wait for its Parameter Store result.
