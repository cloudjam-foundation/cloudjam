# DataExtractionAPP

The application copies processed PostgreSQL records to Parameter Store. Configure `DATABASE_URL`, and optionally `REGION`, `RESULT_PREFIX`, `POLL_INTERVAL`, and `RUN_ONCE`. Keep `RUN_ONCE=false` for an ECS service. Environment variables override config.ini.
