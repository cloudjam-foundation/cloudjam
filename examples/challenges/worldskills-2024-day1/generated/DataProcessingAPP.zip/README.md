# DataProcessingAPP

The application copies new FeedbackTable records into PostgreSQL. Configure `DATABASE_URL`, and optionally `REGION`, `FEEDBACK_TABLE`, `BATCH_STATUS_PARAMETER`, `POLL_INTERVAL`, and `RUN_ONCE`. Set `RUN_ONCE=true` for an AWS Batch job. Environment variables override config.ini.
