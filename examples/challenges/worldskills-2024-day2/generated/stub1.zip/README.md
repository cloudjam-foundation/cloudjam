# stub1

Reference blood-pressure query service. It listens on `PORT` (default: `8080`) and reads `TABLE_NAME` (default: `cloudraiser-iot`).
