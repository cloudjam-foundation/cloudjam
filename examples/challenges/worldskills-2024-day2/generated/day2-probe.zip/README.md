# day2-probe

Run `./day2-probe -blood-pressure-ingest URL -blood-pressure-query URL -enterprise-api URL` to exercise both pipelines.
