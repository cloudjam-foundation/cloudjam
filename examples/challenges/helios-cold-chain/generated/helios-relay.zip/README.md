# Helios EventBridge relay

Deploy `bootstrap` with the `provided.al2023` runtime on arm64. Set `QUEUE_URL` to the telemetry queue and configure the function as the EventBridge rule target.
