# Helios query function

Deploy `bootstrap` with the `provided.al2023` runtime on arm64. Set `RESULT_BUCKET` and expose a Function URL.
