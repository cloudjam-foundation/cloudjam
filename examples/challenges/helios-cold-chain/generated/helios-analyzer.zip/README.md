# Helios analyzer

Deploy `bootstrap` with the `provided.al2023` runtime on arm64. Set `RESULT_BUCKET`, `KMS_KEY_ID`, `LIMITS_SECRET`, and `ALERT_TOPIC_ARN`. Invoke it from an Express Step Functions workflow.
