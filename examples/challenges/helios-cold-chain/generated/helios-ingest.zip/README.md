# Helios ingestion function

Deploy `bootstrap` with the `provided.al2023` runtime on arm64. Set `EVENT_BUS_NAME` to the custom event bus name and expose a Function URL.
