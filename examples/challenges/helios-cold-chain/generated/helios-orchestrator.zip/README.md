# Helios queue orchestrator

Deploy `bootstrap` with the `provided.al2023` runtime on arm64. Set `STATE_MACHINE_ARN`, connect the telemetry SQS queue with partial batch responses enabled, and use a visibility timeout longer than the function timeout.
