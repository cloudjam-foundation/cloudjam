# Helios probe

Run `./helios-probe -ingest-url URL -query-url URL` to submit safe and excursion readings and verify both results.
